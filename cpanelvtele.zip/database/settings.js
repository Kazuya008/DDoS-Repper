const settings = {
  token: '8342337516:AAGBaSctFbN-Liu8j0eccWXG6ocgFwyk9GI',
  adminId: '7591644935', 
  pp: 'https://raw.githubusercontent.com/NdikzDatabase/Database/main/Database/1755183909490-9s5gk1.jpg',
urladmin: 't.me/xinybao',
    //SERVER 1
  domain: 'https://badolkeceserverbot.rullzhosting.my.id/', // domain
  plta: 'ptla_4mDfkKxbwbR8dl1LroDHvvqRgbjtIDan6ZmVcjFdC8G', //  plta yang sesuai
  pltc: 'ptlc_WzSw0wrmrs4da3tMEXvLzPD7YOkApSoxc9SaKFpYpC0', // pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;